# Learning log

## 2026-09-22 — initial distilled state

### Evidence

- User provided a long-form真人直播 sample centered on a皖南土黄鸡 product story.
- Early system output was described as link-heavy and dry.
- After separating style sample, product facts, and prompt rules, user judged the result around 60/100.
- After switching from forced seven content stages to one-pass continuous speech with runtime-only seven audio chunks, user judged a later result 75/100.
- User explicitly stated that reasonable inference is acceptable; the main concern is avoiding absolute claims and advertising-law high-risk wording.

### Stable rules promoted

- Product is the main character; links are actions, not the content spine.
- Learn style from samples but keep sample facts isolated.
- Generate one continuous speech first; chunk only for playback.
- Do not regress later portions into parameter/link recital.
- Allow mild inference with hedged language; block strong certainty and unsupported claims.
- Keep advertising-compliance language checks active.
- Preserve smooth TTS/playback behavior while tuning content unless a runtime defect appears.

### Open quality gap after 75/100

Focus on:

- more consistent human tone from beginning to end;
- richer use of verified product material without formulaic transitions;
- more natural late-stage CTA;
- less AI-style explanatory framing;
- maintaining factual richness when the guard edits risky sentences.
